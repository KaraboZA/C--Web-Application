﻿using LoginAndRegistration.Models;
using Microsoft.AspNetCore.Mvc;

namespace LoginAndRegistration.Controllers
{
    public class DonationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ProcessDonation(Donate donate)
        {
            if (donate.Names.Equals("Karabo Mathibela") && donate.EmailAddress.Equals("banelemathibela56@gmail.com") && donate.Description.Equals("A little something") && donate.Amount == 2500)
            {
                return View("DonationReport", donate);
            }
            else
            {
                return View();
            }

        }
    }
}
