﻿using LoginAndRegistration.Models;
using LoginAndRegistration.Services;
using Microsoft.AspNetCore.Mvc;

namespace LoginAndRegistration.Controllers
{
    public class IncidentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ProcessIncident(IncidentR incidentR)
        {
            if (incidentR.incident.Equals("Explosion") && incidentR.location.Equals("Braamfontein") && incidentR.itemsRequired.Equals("Food, blankets and water"))
            {
                return View("Details", incidentR);
            }
            else 
            {
                return View();
            }

        }
    }
}
