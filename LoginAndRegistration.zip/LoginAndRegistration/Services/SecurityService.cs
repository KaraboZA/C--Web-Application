﻿using LoginAndRegistration.Models;

namespace LoginAndRegistration.Services
{
    public class SecurityService
    {
        List<UserModel> knownUsers = new List<UserModel>();

        public SecurityService() 
        {
            knownUsers.Add(new UserModel { Id = 0, UserName = "KaraboFish", Password = "bigbucks" });
            knownUsers.Add(new UserModel { Id = 1, UserName = "KaraboM", Password = "mathibela" });
            knownUsers.Add(new UserModel { Id = 2, UserName = "KaraboB", Password = "fish" });
        }
        public bool isValid(UserModel user) 
        {
            //THE METHOD WILL RETURN 'true' IF THE USER IS FOUND IN THE LIST
            return knownUsers.Any(x => x.UserName == user.UserName && x.Password == user.Password);
        }
    }
}
