﻿namespace LoginAndRegistration.Models
{
    public class Donate
    {
        public string Names { get; set; }
        public string EmailAddress { get; set; }
        public string Description { get; set; }
        public int Amount { get; set; }

        public Donate() 
        {
            
        }
    }
}
