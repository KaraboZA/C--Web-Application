﻿namespace LoginAndRegistration.Models
{
    public class IncidentR
    {
        public string incident { get; set; }
        public string location { get; set; }
        public string itemsRequired { get; set; }

        public IncidentR() 
        { 
        
        }

    }
}
